# This file marks numword as a Python package

from .number_converter import words_to_number, number_to_words

__all__ = ['words_to_number', 'number_to_words']